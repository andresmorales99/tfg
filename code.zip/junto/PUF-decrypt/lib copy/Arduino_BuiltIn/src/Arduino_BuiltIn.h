// This file intentionally left empty.
// It serves only to make this shell library fully valid.
