Bootloader for source level debugger for Arduino avr_debug
Works for Arduino Uno (ATmega328).
This is copy of the binary file optiboot.hex which can be found in avr_debug/bootloader folder. 
Please see this folder for info on building and using the bootloader.

