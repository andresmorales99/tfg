This is experimental code. 
c - example program for testing the debugger including filling the memory and running avr-gdb from command line.
boot_api_app - Experimental program for testing bootloader API in avr_debug debugger